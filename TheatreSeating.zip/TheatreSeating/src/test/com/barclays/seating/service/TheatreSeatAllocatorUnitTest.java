/**
 * 
 */
package test.com.barclays.seating.service;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.Before;
import org.junit.Test;

import com.barclays.seating.main.TheatreSeatAllocator;

import junit.framework.TestCase;

/**
 * @author n23167
 *
 */
public class TheatreSeatAllocatorUnitTest extends TestCase{

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testSeatAllocation() {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
        System.setOut(new PrintStream(baos));
        TheatreSeatAllocator.main(new String [] {"src/resources/InputData.txt"});
        String output=baos.toString();
        assertEquals("Smith Row 1 Section 1\n"+
        			"Jones Row 2 Section 2\n"+
        		"Davis Row 1 Section 2\n"+
        		"Wilson Sorry, we can't handle your party.\n"+
        		"Johnson Row 2 Section 1\n"+
        		"Williams Row 1 Section 1\n"+
        		"Brown Row 4 Section 2\n"+
        		"Miller Call to split party.\n"
.trim().replace("\r",""),output.trim().replace("\r",""));
	}

}
