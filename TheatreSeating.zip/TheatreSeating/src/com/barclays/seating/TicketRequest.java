/**
 * 
 */
package com.barclays.seating;

/**
 * @author n23167
 *
 */
public class TicketRequest {
	
	private String customerName;
	private int ticketsRequested;
	private boolean isProcessed;
	
	public TicketRequest(String name, String tickets)
	{
		this.customerName = name;
		this.ticketsRequested = Integer.valueOf(tickets);
		
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getTicketsRequested() {
		return ticketsRequested;
	}

	public void setTicketsRequested(int ticketsRequested) {
		this.ticketsRequested = ticketsRequested;
	}
	
	public boolean isProcessed() {
		return isProcessed;
	}

	public void setProcessed(boolean isProcessed) {
		this.isProcessed = isProcessed;
	}

}
