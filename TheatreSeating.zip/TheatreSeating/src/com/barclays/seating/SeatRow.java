/**
 * 
 */
package com.barclays.seating;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Jagadeesh Badri
 *
 */
public class SeatRow {

	private int rowNo;
	private List<SeatSection> seatSections = new ArrayList<>();

	public SeatRow(int rowNumber) {
		this.rowNo = rowNumber;
	}

	public int getRowCapacity() {
		return getSeatSections().stream().mapToInt(section -> section.getSectionCapacity()).sum();
	}

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public List<SeatSection> getSeatSections() {
		return seatSections;
	}

	public void setSeatSections(List<SeatSection> seatSections) {
		this.seatSections = seatSections;
	}

}
