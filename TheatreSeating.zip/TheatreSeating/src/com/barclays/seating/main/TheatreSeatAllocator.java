/**
 * 
 */
package com.barclays.seating.main;


import java.util.List;
import java.util.Scanner;

import com.barclays.seating.SeatRow;
import com.barclays.seating.TicketRequest;
import com.barclays.seating.service.SeatAllocationService;
import com.barclays.seating.utils.TheatreParseUtil;

/**
 * @author Jagadeesh Badri
 *
 */
public class TheatreSeatAllocator {

	public static void main(String[] args) {
		
		// Get Input File
		Scanner scan = TheatreParseUtil.parseInputFile(args);
		if (scan == null)
		{
			throw new IllegalArgumentException(
					"Please refer to readme for the input data format.");
		}
		// build seat layout
		List<SeatRow> seatRows = TheatreParseUtil.parseSeatingLayout(scan);
		
		// build customer request
		List<TicketRequest> ticketRequests = TheatreParseUtil.parseTicketRequest(scan);
		
		// allocate Seats
		String seatAllocation = SeatAllocationService.allocateSeats(seatRows,ticketRequests);
		
		System.out.println(seatAllocation);
		
		
		
	}
}
