/**
 * 
 */
package com.barclays.seating;

/**
 * @author n23167
 *
 */
public class SeatLayout {
	
	private SeatRow seatRow;
	private SeatSection seatSection;


}
