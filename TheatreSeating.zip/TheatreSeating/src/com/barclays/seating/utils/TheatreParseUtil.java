/**
 * 
 */
package com.barclays.seating.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.barclays.seating.SeatRow;
import com.barclays.seating.SeatSection;
import com.barclays.seating.TicketRequest;

/**
 * @author n23167
 *
 */
public class TheatreParseUtil {
	
	public static List<SeatRow> parseSeatingLayout(Scanner scan)
	{
		String next = scan.nextLine();
		int rowNumber = 0;
		List<SeatRow> seats = new ArrayList<>();
		while (next.length() != 0) {
			rowNumber += 1;
			int sectionNo = 0;			
			String[] sections = next.trim().split("\\s+");
			SeatRow seatRow = new SeatRow(rowNumber);
			for(String section : sections)
			{
				sectionNo += 1;
				seatRow.getSeatSections().add((new SeatSection(sectionNo, section)));				
			}
			seats.add(seatRow);
			if (!scan.hasNextLine()) {
				return seats;
			} 
			next = scan.nextLine();
		}
		return seats;
		
	}
	
	public static List<TicketRequest> parseTicketRequest(Scanner scan)
	{
		String next = scan.nextLine();
		
		List<TicketRequest> ticketRequests = new ArrayList<>();
		while (next.length() != 0) 					
		{	 	
			String[] requests = next.trim().split("\\s+");
			if (requests.length >= 2) {
				ticketRequests.add(new TicketRequest(requests[0], requests[1]));
			} else {
				throw new IllegalArgumentException(
						"Please refer to readme for the input data format.");
			}
			if (!scan.hasNextLine()) {
				return ticketRequests;
			} 
			next = scan.nextLine();
		}
		return ticketRequests;		
	}
	
	public static Scanner parseInputFile(String[] args)
	{
		if (args.length > 0) {
			File inputDataFile = new File(args[0].trim());
			if (inputDataFile.exists()) {
				try {
					return new Scanner(inputDataFile);
				} catch (FileNotFoundException fnfex) {
					throw new IllegalArgumentException(
							" Please refer to readme for the input data format.");
				}
			} else {
				throw new IllegalArgumentException(
						"Please refer to readme for the input data format.");
			}
		}	
		return null;
	}

}
