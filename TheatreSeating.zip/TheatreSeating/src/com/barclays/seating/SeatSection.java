/**
 * 
 */
package com.barclays.seating;

/**
 * @author n23167
 *
 */
public class SeatSection {
	
	private int seatSectionNo;
	private int sectionCapacity;

	public SeatSection(int section, String capacity ) {	
		
		this.seatSectionNo = section;
		this.sectionCapacity = Integer.valueOf(capacity);
	}

	
	public int getSeatSectionNo() {
		return seatSectionNo;
	}

	public void setSeatSectionNo(int seatSectionNo) {
		this.seatSectionNo = seatSectionNo;
	}

	public int getSectionCapacity() {
		return sectionCapacity;
	}

	public void setSectionCapacity(int sectionCapacity) {
		this.sectionCapacity = sectionCapacity;
	}

}
