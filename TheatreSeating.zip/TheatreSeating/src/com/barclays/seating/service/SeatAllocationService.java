package com.barclays.seating.service;

import java.util.List;

import com.barclays.seating.SeatRow;
import com.barclays.seating.SeatSection;
import com.barclays.seating.TicketRequest;

public class SeatAllocationService {

	public static String allocateSeats(List<SeatRow> seatRows, List<TicketRequest> ticketRequests) {

		StringBuilder seatAllocation = new StringBuilder();
		int seatRowLimit = (seatRows.size() - 1) / 2;
		int totalTheatreCapacity = seatRows.stream().mapToInt(seatRow -> seatRow.getRowCapacity()).sum();

		for (TicketRequest ticket : ticketRequests) {

			if (ticket.getTicketsRequested() > totalTheatreCapacity) {
				seatAllocation.append(ticket.getCustomerName() + " Sorry, we can't handle your party.\n");
				ticket.setProcessed(true);
			}
			// find exact Match front to the theatre
			seatAllocate(seatRowLimit, ticket, 0, seatRows, seatAllocation);
			// find nearest Match front to the theatre
			seatAllocate(seatRowLimit, ticket, 1, seatRows, seatAllocation);
			// find exact match any where to theatre
			seatAllocate(seatRows.size() - 1, ticket, 0, seatRows, seatAllocation);
			// find nearest Match any where in theatre
			seatAllocate(seatRows.size() - 1, ticket, 1, seatRows, seatAllocation);

			if (!ticket.isProcessed()) {
				seatAllocation.append(ticket.getCustomerName() + " Call to split party.\n");
				ticket.setProcessed(true);
			}

		}
		return seatAllocation.toString();
	}

	private static void seatAllocate(int seatRowLimit, TicketRequest ticket, int compareValue, List<SeatRow> seatRows,
			StringBuilder seatAllocation) {
		for (int i = 0; i <= seatRowLimit; i++) {
			if (ticket.isProcessed())
				break;
			for (SeatSection section : seatRows.get(i).getSeatSections()) {
				if (Integer.compare(section.getSectionCapacity(), ticket.getTicketsRequested()) == compareValue) {

					seatAllocation.append(ticket.getCustomerName() + " Row " + seatRows.get(i).getRowNo() + " Section "
							+ section.getSeatSectionNo());
					seatAllocation.append("\n");

					section.setSectionCapacity(section.getSectionCapacity() - ticket.getTicketsRequested());
					ticket.setProcessed(true);
					break;
				}
			}

		}
	}

}
